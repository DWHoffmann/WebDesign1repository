<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Example</title>
    <script src="toolKit.js" defer></script>
    <style>
        .error-message {
            color: red;
            margin-left: 10px;
        }
    </style>
</head>
<body>

    <div id="form-container"></div>

    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Create a form
            const form = createForm('myForm', 'formSubmit.php', 'POST');

            // Add form fields
            addFormField(form, 'text', 'name', 'Name:');
            addFormField(form, 'email', 'email', 'Email:');
            addFormField(form, 'password', 'password', 'Password:');
            addFormField(form, 'text', 'dob', 'Date of Birth (MM/DD/YYYY):');  // Changed to text input

            // Add a submit button to the form
            const submitButton = document.createElement('button');
            submitButton.type = 'submit';
            submitButton.innerText = 'Submit';
            form.appendChild(submitButton);

            // Append the form to the container
            document.getElementById('form-container').appendChild(form);

            // Add submit event listener
            addSubmitEventListener(form, async (event) => {
                let isValid = true;

                // Validate the name field
                const nameField = form.querySelector('[name="name"]');
                if (!validateRequired(nameField.value)) {
                    showErrorMessage(nameField, 'Name is required');
                    isValid = false;
                } else {
                    clearErrorMessage(nameField);
                }

                // Validate the email field
                const emailField = form.querySelector('[name="email"]');
                if (!validateEmail(emailField.value)) {
                    showErrorMessage(emailField, 'Invalid email address');
                    isValid = false;
                } else {
                    clearErrorMessage(emailField);
                }

                // Validate the password field
                const passwordField = form.querySelector('[name="password"]');
                if (!validatePassword(passwordField.value)) {
                    showErrorMessage(passwordField, 'Password must be at least 8 characters long, include a number, a lowercase and an uppercase letter');
                    isValid = false;
                } else {
                    clearErrorMessage(passwordField);
                }

                // Validate the date of birth field
                const dobField = form.querySelector('[name="dob"]');
                if (!validateDate(dobField.value)) {
                    showErrorMessage(dobField, 'Date must be in the format MM/DD/YYYY');
                    isValid = false;
                } else {
                    clearErrorMessage(dobField);
                }

                // If form is valid, submit the data using AJAX
                if (isValid) {
                    const data = {
                        name: nameField.value,
                        email: emailField.value,
                        password: passwordField.value,
                        dob: dobField.value
                    };
                    const response = await submitFormData(form.action, data);
                    handleResponse(response);
                }
            });

            // Real-time validation for the email field
            const emailField = form.querySelector('[name="email"]');
            addInputEventListener(emailField, () => {
                if (!validateEmail(emailField.value)) {
                    showErrorMessage(emailField, 'Invalid email address');
                } else {
                    clearErrorMessage(emailField);
                }
            });

            // Real-time validation for the password field
            const passwordField = form.querySelector('[name="password"]');
            addInputEventListener(passwordField, () => {
                if (!validatePassword(passwordField.value)) {
                    showErrorMessage(passwordField, 'Password must be at least 8 characters long, include a number, a lowercase and an uppercase letter');
                } else {
                    clearErrorMessage(passwordField);
                }
            });

            // Real-time validation for the date of birth field
            const dobField = form.querySelector('[name="dob"]');
            addInputEventListener(dobField, () => {
                if (!validateDate(dobField.value)) {
                    showErrorMessage(dobField, 'Date must be in the format MM/DD/YYYY');
                } else {
                    clearErrorMessage(dobField);
                }
            });

        });

        function validateDate(date) {
            const regex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/;
            return regex.test(date);
        }
    </script>

</body>
</html>