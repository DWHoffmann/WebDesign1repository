// DOM Manipulation for Form Creation

function createForm(id = '', action = '#', method = 'POST') {
  const form = document.createElement('form');
  form.id = id;
  form.action = action;
  form.method = method;
  return form;
}

function addFormField(form, type, name, label = '') {
  const fieldWrapper = document.createElement('div');

  if (label) {
    const labelElement = document.createElement('label');
    labelElement.htmlFor = name;
    labelElement.innerHTML = label;
    fieldWrapper.appendChild(labelElement);
  }

  const input = document.createElement('input');
  input.type = type;
  input.name = name;
  input.id = name;

  fieldWrapper.appendChild(input);
  form.appendChild(fieldWrapper);
}

function createTextInput(name, label = '') {
  return createFormField('text', name, label);
}

function createDropdown(name, options = [], label = '') {
  const fieldWrapper = document.createElement('div');

  if (label) {
    const labelElement = document.createElement('label');
    labelElement.htmlFor = name;
    labelElement.innerHTML = label;
    fieldWrapper.appendChild(labelElement);
  }

  const select = document.createElement('select');
  select.name = name;
  select.id = name;

  options.forEach(optionText => {
    const option = document.createElement('option');
    option.value = optionText;
    option.innerHTML = optionText;
    select.appendChild(option);
  });

  fieldWrapper.appendChild(select);
  return fieldWrapper;
}

function addFormFieldDynamically(form, inputType, name) {
  const newField = document.createElement('input');
  newField.type = inputType;
  newField.name = name;
  form.appendChild(newField);
}

// Event Handling for Forms

function addSubmitEventListener(form, callback) {
  form.addEventListener('submit', event => {
    event.preventDefault();
    callback(event);
  });
}

function addInputEventListener(input, callback) {
  input.addEventListener('input', callback);
}

// Form Validation Utilities

function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(String(email).toLowerCase());
}

function validatePassword(password) {
  const re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
  return re.test(String(password));
}

function validateRequired(value) {
  return value.trim() !== '';
}

function validateRegex(value, pattern) {
  const re = new RegExp(pattern);
  return re.test(value);
}

function validateDate(date) {
  const regex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/;
  return regex.test(date);
}

// AJAX Helpers for Form Submission

async function submitFormData(url, data) {
  alert(url);
  alert(data);
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data)
    });

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}

function handleResponse(response) {
  if (response.success) {
    alert('Form submitted successfully!');
  } else {
    alert('Error submitting form.');
  }
}

// Utility Functions

function formatPhoneNumber(input) {
  input = input.replace(/\D/g, '');
  if (input.length <= 3) return input;
  if (input.length <= 7) return input.replace(/(\d{3})(\d{1,4})/, '($1) $2');
  return input.replace(/(\d{3})(\d{1,3})(\d{1,4})/, '($1) $2-$3');
}

function capitalizeName(input) {
  return input.replace(/\b\w/g, char => char.toUpperCase());
}

function formatDates(input) {
  return input.replace(/(\d{2})(\d{2})(\d{4})/, '$1/$2/$3');
}

function showErrorMessage(field, message) {
  let errorElement = field.nextElementSibling;
  if (!errorElement || !errorElement.classList.contains('error-message')) {
    errorElement = document.createElement('span');
    errorElement.classList.add('error-message');
    field.parentNode.insertBefore(errorElement, field.nextSibling);
  }
  errorElement.innerHTML = message;
}

function clearErrorMessage(field) {
  const errorElement = field.nextElementSibling;
  if (errorElement && errorElement.classList.contains('error-message')) {
    errorElement.innerHTML = '';
  }
}
