<?php

class LogLevel
{
    const DEBUG = 0;
    const INFO = 1;
    const WARNING = 2;
    const ERROR = 3;

    public static function getName(int $level): string
    {
        switch ($level) {
            case self::DEBUG:
                return 'DEBUG';
            case self::INFO:
                return 'INFO';
            case self::WARNING:
                return 'WARNING';
            case self::ERROR:
                return 'ERROR';
            default:
                throw new \InvalidArgumentException("Invalid log level: $level");
        }
    }
}

class Logger
{
    private string $filePath;
    private int $logLevel;

    public function __construct(string $filePath, int $logLevel = LogLevel::DEBUG)
    {
        $this->filePath = $filePath;
        $this->logLevel = $logLevel;
    }

    private function shouldLog(int $level): bool
    {
        return $level >= $this->logLevel;
    }

    private function log(int $level, string $message): void
    {
        if (!$this->shouldLog($level)) {
            return;
        }

        $formattedMessage = $this->formatMessage($level, $message);
        $this->writeToConsole($formattedMessage);
        $this->writeToFile($formattedMessage);
    }

    private function formatMessage(int $level, string $message): string
    {
        $timestamp = date('Y-m-d H:i:s');
        $levelName = LogLevel::getName($level);
        return "[$timestamp] {$levelName}: $message";
    }

    private function writeToConsole(string $message): void
    {
        echo $message . PHP_EOL;
    }

    private function writeToFile(string $message): void
    {
        try {
            $logDirectory = dirname($this->filePath);

            if (!is_dir($logDirectory)) {
                mkdir($logDirectory, 0777, true);
            }

            file_put_contents($this->filePath, $message . PHP_EOL, FILE_APPEND);
        } catch (\Exception $e) {
            error_log("Failed to write to log file: " . $e->getMessage());
        }
    }

    public function debug(string $message): void
    {
        $this->log(LogLevel::DEBUG, $message);
    }

    public function info(string $message): void
    {
        $this->log(LogLevel::INFO, $message);
    }

    public function warning(string $message): void
    {
        $this->log(LogLevel::WARNING, $message);
    }

    public function error(string $message): void
    {
        $this->log(LogLevel::ERROR, $message);
    }
}

// Usage example
$logger = new Logger(__DIR__ . '/log/file.log');

$logger->debug("This is a debug message");
$logger->info("This is an info message");
$logger->warning("This is a warning message");
$logger->error("This is an error message");
?>