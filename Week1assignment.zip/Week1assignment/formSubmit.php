<?php
// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JSON input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    // Prepare the log entry
    $logEntry = sprintf(
        "[%s] Name: %s, Email: %s, Password: %s, Date of Birth: %s\n",
        date('Y-m-d H:i:s'),
        $data['name'],
        $data['email'],
        $data['password'],
        $data['dob']
    );

    // Ensure the log directory exists
    $logDirectory = __DIR__ . '/log';
    if (!is_dir($logDirectory)) {
        mkdir($logDirectory, 0777, true);
    }

    // Write the log entry to a file within the log directory
    $logFile = $logDirectory . '/form_submissions.log';
    file_put_contents($logFile, $logEntry, FILE_APPEND);

    // Send a JSON response
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Form submitted successfully']);
} else {
    // Send a 405 Method Not Allowed response if the request method is not POST
    header('HTTP/1.1 405 Method Not Allowed');
    echo "Method Not Allowed";
}